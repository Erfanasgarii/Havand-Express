<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isCourier()) {
    redirect('../login.php', 'لطفاً به عنوان سفیر وارد شوید', 'error');
}

$courierId = $_SESSION['user_id'];

// دریافت موجودی
$stmt = $conn->prepare("SELECT balance FROM wallet WHERE courier_id = ?");
$stmt->execute([$courierId]);
$wallet = $stmt->fetch();
if (!$wallet) {
    $stmt = $conn->prepare("INSERT INTO wallet (courier_id, balance) VALUES (?, 0)");
    $stmt->execute([$courierId]);
    $wallet = ['balance' => 0];
}

// دریافت تراکنش‌ها
$stmt = $conn->prepare("SELECT amount, type, description, created_at 
                        FROM wallet_transactions 
                        WHERE courier_id = ? 
                        ORDER BY created_at DESC");
$stmt->execute([$courierId]);
$transactions = $stmt->fetchAll();

// دریافت درخواست‌های برداشت
$stmt = $conn->prepare("SELECT amount, sheba, card_number, status, rejection_reason, created_at 
                        FROM withdrawal_requests 
                        WHERE courier_id = ? 
                        ORDER BY created_at DESC");
$stmt->execute([$courierId]);
$requests = $stmt->fetchAll();

// ثبت درخواست برداشت
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_withdrawal'])) {
    $amount = (int)$_POST['amount'];
    $sheba = trim($_POST['sheba']);
    $cardNumber = trim($_POST['card_number']);

    if ($amount < MIN_WITHDRAWAL_AMOUNT) {
        setError('حداقل مبلغ برداشت ' . number_format(MIN_WITHDRAWAL_AMOUNT) . ' تومان است');
    } elseif ($amount > $wallet['balance']) {
        setError('موجودی کافی نیست');
    } elseif (!preg_match('/^IR[0-9]{24}$/', $sheba) && !preg_match('/^[0-9]{16}$/', $cardNumber)) {
        setError('شماره شبا یا کارت نامعتبر است');
    } else {
        $stmt = $conn->prepare("INSERT INTO withdrawal_requests (courier_id, amount, sheba, card_number, status, created_at) 
                                VALUES (?, ?, ?, ?, 'pending', NOW())");
        $stmt->execute([$courierId, $amount, $sheba ?: null, $cardNumber ?: null]);
        redirect('wallet.php', 'درخواست برداشت ثبت شد', 'success');
    }
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>کیف پول - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>کیف پول</h2>
        <nav>
            <a href="index.php">مرسولات در انتظار</a>
            <a href="parcels.php">مرسولات من</a>
            <a href="wallet.php">کیف پول</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <h3>موجودی: <?php echo number_format($wallet['balance']); ?> تومان</h3>
        <button onclick="document.getElementById('withdrawal-modal').style.display='block'">درخواست برداشت</button>
        <h3>تراکنش‌ها</h3>
        <table>
            <thead>
                <tr>
                    <th>مبلغ (تومان)</th>
                    <th>نوع</th>
                    <th>توضیحات</th>
                    <th>تاریخ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $txn): ?>
                    <tr>
                        <td><?php echo number_format($txn['amount']); ?></td>
                        <td><?php echo $txn['type'] === 'deposit' ? 'واریز' : 'برداشت'; ?></td>
                        <td><?php echo htmlspecialchars($txn['description']); ?></td>
                        <td><?php echo toShamsi($txn['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <h3>درخواست‌های برداشت</h3>
        <table>
            <thead>
                <tr>
                    <th>مبلغ (تومان)</th>
                    <th>شبا</th>
                    <th>کارت</th>
                    <th>وضعیت</th>
                    <th>دلیل رد</th>
                    <th>تاریخ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $req): ?>
                    <tr>
                        <td><?php echo number_format($req['amount']); ?></td>
                        <td><?php echo htmlspecialchars($req['sheba'] ?: '-'); ?></td>
                        <td><?php echo htmlspecialchars($req['card_number'] ?: '-'); ?></td>
                        <td class="<?php echo $req['status'] === 'pending' ? 'status-pending' : ($req['status'] === 'approved' ? 'status-approved' : 'status-rejected'); ?>">
                            <?php echo ['pending' => 'در انتظار تأیید', 'approved' => 'تأیید شده', 'rejected' => 'رد شده'][$req['status']]; ?>
                        </td>
                        <td><?php echo htmlspecialchars($req['rejection_reason'] ?: '-'); ?></td>
                        <td><?php echo toShamsi($req['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <!-- مودال برداشت -->
        <div id="withdrawal-modal" class="modal" style="display: none;">
            <div class="modal-content">
                <span class="close" onclick="document.getElementById('withdrawal-modal').style.display='none'">&times;</span>
                <h3>درخواست برداشت</h3>
                <form method="POST" action="" id="withdrawal-form">
                    <div class="form-group">
                        <label for="amount">مبلغ (تومان)</label>
                        <input type="number" name="amount" id="amount" required>
                    </div>
                    <div class="form-group">
                        <label for="sheba">شماره شبا</label>
                        <input type="text" name="sheba" id="sheba" placeholder="IRxxxxxxxxxxxxxxxxxxxxxxxx">
                    </div>
                    <div class="form-group">
                        <label for="card_number">شماره کارت</label>
                        <input type="text" name="card_number" id="card_number" placeholder="xxxxxxxxxxxxxxxx">
                    </div>
                    <button type="submit" name="request_withdrawal">ثبت درخواست</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>