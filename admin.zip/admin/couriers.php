<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php', 'لطفاً به عنوان ادمین وارد شوید', 'error');
}

// دریافت لیست سفیرها
$stmt = $conn->prepare("SELECT id, name, mobile FROM users WHERE role = 'courier'");
$stmt->execute();
$couriers = $stmt->fetchAll();

// ایجاد سفیر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_courier'])) {
    $name = trim($_POST['name']);
    $mobile = trim($_POST['mobile']);

    if (!validateMobile($mobile)) {
        setError('شماره موبایل نامعتبر است');
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE mobile = ?");
        $stmt->execute([$mobile]);
        if ($stmt->fetch()) {
            setError('این شماره موبایل قبلاً ثبت شده است');
        } else {
            $stmt = $conn->prepare("INSERT INTO users (name, mobile, role, created_at) VALUES (?, ?, 'courier', NOW())");
            $stmt->execute([$name, $mobile]);
            redirect('couriers.php', 'سفیر با موفقیت اضافه شد', 'success');
        }
    }
}

// ویرایش سفیر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_courier'])) {
    $id = (int)$_POST['id'];
    $name = trim($_POST['name']);
    $mobile = trim($_POST['mobile']);

    if (!validateMobile($mobile)) {
        setError('شماره موبایل نامعتبر است');
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE mobile = ? AND id != ?");
        $stmt->execute([$mobile, $id]);
        if ($stmt->fetch()) {
            setError('این شماره موبایل قبلاً ثبت شده است');
        } else {
            $stmt = $conn->prepare("UPDATE users SET name = ?, mobile = ? WHERE id = ?");
            $stmt->execute([$name, $mobile, $id]);
            redirect('couriers.php', 'سفیر با موفقیت ویرایش شد', 'success');
        }
    }
}

// حذف سفیر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_courier'])) {
    $id = (int)$_POST['id'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'courier'");
    $stmt->execute([$id]);
    redirect('couriers.php', 'سفیر با موفقیت حذف شد', 'success');
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت سفیرها - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>مدیریت سفیرها</h2>
        <nav>
            <a href="index.php">داشبورد</a>
            <a href="parcels.php">مدیریت مرسولات</a>
            <a href="couriers.php">مدیریت سفیرها</a>
            <a href="withdrawals.php">درخواست‌های برداشت</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <h3>اضافه کردن سفیر</h3>
        <form method="POST" action="">
            <div class="form-group">
                <label for="name">نام</label>
                <input type="text" name="name" id="name" required>
            </div>
            <div class="form-group">
                <label for="mobile">شماره موبایل</label>
                <input type="text" name="mobile" id="mobile" required>
            </div>
            <button type="submit" name="add_courier">اضافه کردن</button>
        </form>
        <h3>لیست سفیرها</h3>
        <table>
            <thead>
                <tr>
                    <th>نام</th>
                    <th>موبایل</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($couriers as $courier): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($courier['name']); ?></td>
                        <td><?php echo htmlspecialchars($courier['mobile']); ?></td>
                        <td>
                            <form method="POST" action="" style="display: inline;">
                                <input type="hidden" name="id" value="<?php echo $courier['id']; ?>">
                                <input type="text" name="name" value="<?php echo htmlspecialchars($courier['name']); ?>">
                                <input type="text" name="mobile" value="<?php echo htmlspecialchars($courier['mobile']); ?>">
                                <button type="submit" name="edit_courier">ویرایش</button>
                            </form>
                            <form method="POST" action="" style="display: inline;">
                                <input type="hidden" name="id" value="<?php echo $courier['id']; ?>">
                                <button type="submit" name="delete_courier" onclick="return confirm('آیا مطمئن هستید که می‌خواهید این سفیر را حذف کنید؟');">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>