<?php
// تنظیمات اصلی پروژه

// تنظیمات دیتابیس
define('DB_HOST', 'localhost');
define('DB_USER', 'havandir_ex21user');
define('DB_PASS', 'm3LHOT5*mo+AYx{8');
define('DB_NAME', 'havandir_ex21');
define('DB_PORT', '3306');
define('DB_CHARSET', 'utf8mb4');

// تنظیمات SMS.ir
define('SMS_API_KEY', 'DvWh7gYdHQWcFwoGHJ6Zw57XlQUh9Jvbq9SeGqftkEdNqAf4');
define('SMS_PATTERN_ID', '358841');
define('SMS_TEST_NUMBER', '09191167379');

// تنظیمات Map.ir
define('MAPIR_API_KEY', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjlkNTc1YWFkY2ViZDcyYWY1MWUxNzJlYzU0MjFmODBmMTMxZDcxN2JkOTI4MGY2NGYwMDExMjk4OTQzNTNlMWE5MzY4Y2M3Mzc4NDE2ODI0In0.eyJhdWQiOiIzNDExMCIsImp0aSI6IjlkNTc1YWFkY2ViZDcyYWY1MWUxNzJlYzU0MjFmODBmMTMxZDcxN2JkOTI4MGY2NGYwMDExMjk4OTQzNTNlMWE5MzY4Y2M3Mzc4NDE2ODI0IiwiaWF0IjoxNzU2NDk2NzAzLCJuYmYiOjE3NTY0OTY3MDMsImV4cCI6MTc1OTA4ODcwMywic3ViIjoiIiwic2NvcGVzIjpbImJhc2ljIl19.Kqy7D9cJQb0W482OMca7D1VED5m_-KdCseAnTkWRDRHy1Y2DkU0k93jImkSltqG4Q7FB2hsOQ6VRfHi6XwVBBBys8HYhRpjS_NVwLtFWK8YtsQdzdRKDquZ1EDjAACtih5OGlRw71MyDg4jx0JoKAibowDO8YVHJgK59YNHpZuDv_bt9dqDmwxdAZ-ti9gXKAprUv3hr487o5eTWWRQpi6mXAmJR7M1Amn2MpCsCOQ3aABjg0CG8oLpM7jV3ThIQBrEVRX8SjlKnv_GmRZiSWOjwBXvfVb4TJjNPUSZM3lCbAYJWy3aVeBu0vcJ74SjVrZZpipA2tiTYJxciIpl8Ow');

// تنظیمات عمومی
date_default_timezone_set('Asia/Tehran');
define('MIN_WITHDRAWAL_AMOUNT', 500000);
define('OTP_EXPIRY_SECONDS', 120);
define('MAX_OTP_ATTEMPTS', 3);
define('MAX_DELIVERY_CODE_ATTEMPTS', 3);

// تنظیمات فونت و UI
define('FONT_FAMILY', 'Vazir');
define('THEME_COLOR', '#800080');