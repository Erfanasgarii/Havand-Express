<?php
require_once 'includes/auth.php';
require_once 'includes/sms_api.php';
require_once 'includes/functions.php';

$step = isset($_POST['step']) ? $_POST['step'] : 'mobile';
$mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 'send_otp') {
        $user = checkLogin($mobile);
        if ($user) {
            $otp = sprintf("%04d", rand(0, 9999)); // کد ۴ رقمی تصادفی
            $sms = new SMSIR();
            if ($sms->sendOTP($mobile, $otp)) {
                saveOTP($mobile, $otp, $user['id']);
                setSuccess('کد تأیید به شماره شما ارسال شد');
                $step = 'verify_otp';
            } else {
                $error = $_SESSION['error'];
            }
        } else {
            $error = $_SESSION['error'];
        }
    } elseif ($step === 'verify_otp') {
        $otp = trim($_POST['otp'] ?? '');
        if (verifyOTP($mobile, $otp)) {
            $role = $_SESSION['user_role'];
            redirect($role === 'admin' ? 'admin/index.php' : 'courier/index.php', 'ورود موفقیت‌آمیز بود', 'success');
        } else {
            $error = $_SESSION['error'];
        }
    }
}

unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود - فروشگاه هاوند</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/vazir.css">
    <script src="assets/js/script.js" defer></script>
</head>
<body>
    <div class="login-container">
        <h2>ورود به سیستم</h2>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <?php if ($step === 'mobile'): ?>
            <form method="POST" action="login.php" id="mobile-form">
                <input type="hidden" name="step" value="send_otp">
                <div class="form-group">
                    <label for="mobile">شماره موبایل</label>
                    <input type="text" name="mobile" id="mobile" value="<?php echo htmlspecialchars($mobile); ?>" required>
                </div>
                <button type="submit">ارسال کد تأیید</button>
            </form>
        <?php elseif ($step === 'verify_otp'): ?>
            <form method="POST" action="login.php" id="otp-form">
                <input type="hidden" name="step" value="verify_otp">
                <input type="hidden" name="mobile" value="<?php echo htmlspecialchars($mobile); ?>">
                <div class="form-group">
                    <label for="otp">کد تأیید</label>
                    <input type="text" name="otp" id="otp" maxlength="4" required>
                </div>
                <button type="submit">تأیید کد</button>
                <button type="button" id="resend-otp" disabled>ارسال مجدد (۱۲۰ ثانیه)</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>