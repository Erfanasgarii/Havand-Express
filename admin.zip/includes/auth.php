<?php
session_start();
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

function checkLogin($mobile) {
    global $conn;
    if (!validateMobile($mobile)) {
        setError('شماره موبایل نامعتبر است');
        return false;
    }

    $stmt = $conn->prepare("SELECT id, role FROM users WHERE mobile = ?");
    $stmt->execute([$mobile]);
    $user = $stmt->fetch();

    if (!$user) {
        setError('کاربری با این شماره موبایل یافت نشد');
        return false;
    }

    return $user;
}

function saveOTP($mobile, $otp, $userId) {
    global $conn;
    $hashedOTP = hashCode($otp);
    // استفاده از Asia/Tehran برای ذخیره زمان دقیق
    $expireTime = date('Y-m-d H:i:s', strtotime('+300 seconds')); // ۵ دقیقه برای تست

    // پاک کردن OTPهای قدیمی برای این موبایل
    $stmt = $conn->prepare("DELETE FROM otps WHERE mobile = ?");
    $stmt->execute([$mobile]);

    $stmt = $conn->prepare("INSERT INTO otps (mobile, otp_code, expire_time, user_id, attempts) VALUES (?, ?, ?, ?, 0)");
    return $stmt->execute([$mobile, $hashedOTP, $expireTime, $userId]);
}

function verifyOTP($mobile, $otp) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, otp_code, expire_time, user_id, attempts FROM otps WHERE mobile = ? ORDER BY expire_time DESC LIMIT 1");
    $stmt->execute([$mobile]);
    $record = $stmt->fetch();

    if (!$record) {
        setError('کد تأیید یافت نشد');
        return false;
    }

    // مقایسه زمان با Asia/Tehran
    $currentTime = time();
    $expireTimestamp = strtotime($record['expire_time']);
    if ($expireTimestamp < $currentTime) {
        setError('کد تأیید منقضی شده است');
        return false;
    }

    if ($record['attempts'] >= MAX_OTP_ATTEMPTS) {
        setError('حداکثر تلاش برای ورود انجام شده است');
        return false;
    }

    if (!verifyCode($otp, $record['otp_code'])) {
        $stmt = $conn->prepare("UPDATE otps SET attempts = attempts + 1 WHERE id = ?");
        $stmt->execute([$record['id']]);
        setError('کد تأیید نادرست است');
        return false;
    }

    // ذخیره session
    $stmt = $conn->prepare("SELECT id, name, mobile, role FROM users WHERE id = ?");
    $stmt->execute([$record['user_id']]);
    $user = $stmt->fetch();

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_mobile'] = $user['mobile'];
    $_SESSION['user_role'] = $user['role'];

    // حذف OTP بعد از تأیید
    $stmt = $conn->prepare("DELETE FROM otps WHERE id = ?");
    $stmt->execute([$record['id']]);

    return true;
}

function logout() {
    session_unset();
    session_destroy();
    redirect('login.php', 'با موفقیت خارج شدید', 'success');
}