<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isCourier()) {
    redirect('../login.php', 'لطفاً به عنوان سفیر وارد شوید', 'error');
}

$parcelId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$courierId = $_SESSION['user_id'];

// دریافت جزئیات مرسوله
$stmt = $conn->prepare("SELECT * FROM parcels WHERE id = ? AND assigned_courier_id = ?");
$stmt->execute([$parcelId, $courierId]);
$parcel = $stmt->fetch();

if (!$parcel) {
    redirect('parcels.php', 'مرسوله یافت نشد یا متعلق به شما نیست', 'error');
}

// تغییر وضعیت
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $newStatus = $_POST['status'];
    $deliveryCode = $_POST['delivery_code'] ?? '';

    // چک کردن کد تحویل برای وضعیت تحویل شده
    if ($newStatus === 'delivered') {
        $stmt = $conn->prepare("SELECT attempts FROM parcels WHERE id = ?");
        $stmt->execute([$parcelId]);
        $attempts = $stmt->fetchColumn();

        if (!verifyCode($deliveryCode, $parcel['delivery_code'])) {
            $stmt = $conn->prepare("UPDATE parcels SET attempts = attempts + 1 WHERE id = ?");
            $stmt->execute([$parcelId]);
            setError('کد تحویل نادرست است');
        } elseif ($attempts >= MAX_DELIVERY_CODE_ATTEMPTS) {
            setError('حداکثر تلاش برای کد تحویل انجام شده است');
        } else {
            $conn->beginTransaction();
            try {
                // آپدیت وضعیت
                $stmt = $conn->prepare("UPDATE parcels SET status = ? WHERE id = ?");
                $stmt->execute([$newStatus, $parcelId]);

                // ثبت تاریخچه
                $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$parcelId, $newStatus, $courierId]);

                // واریز دستمزد
                $stmt = $conn->prepare("UPDATE wallet SET balance = balance + ?, updated_at = NOW() WHERE courier_id = ?");
                $stmt->execute([$parcel['courier_fee'], $courierId]);

                $stmt = $conn->prepare("INSERT INTO wallet_transactions (courier_id, amount, type, description, created_at) 
                                        VALUES (?, ?, 'deposit', ?, NOW())");
                $stmt->execute([$courierId, $parcel['courier_fee'], "دستمزد مرسوله شماره $parcelId"]);

                $conn->commit();
                redirect('parcels.php', 'وضعیت با موفقیت آپدیت شد', 'success');
            } catch (Exception $e) {
                $conn->rollBack();
                setError('خطا در آپدیت وضعیت: ' . $e->getMessage());
            }
        }
    } else {
        $conn->beginTransaction();
        try {
            $stmt = $conn->prepare("UPDATE parcels SET status = ? WHERE id = ?");
            $stmt->execute([$newStatus, $parcelId]);

            $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$parcelId, $newStatus, $courierId]);

            $conn->commit();
            redirect('parcels.php', 'وضعیت با موفقیت آپدیت شد', 'success');
        } catch (Exception $e) {
            $conn->rollBack();
            setError('خطا در آپدیت وضعیت: ' . $e->getMessage());
        }
    }
}

// لغو مرسوله
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_parcel'])) {
    $conn->beginTransaction();
    try {
        $stmt = $conn->prepare("UPDATE parcels SET status = 'pending', assigned_courier_id = NULL, attempts = 0 WHERE id = ?");
        $stmt->execute([$parcelId]);

        $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, 'pending', ?, NOW())");
        $stmt->execute([$parcelId, $courierId]);

        $conn->commit();
        redirect('parcels.php', 'مرسوله با موفقیت لغو شد', 'success');
    } catch (Exception $e) {
        $conn->rollBack();
        setError('خطا در لغو مرسوله: ' . $e->getMessage());
    }
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت مرسوله - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>مدیریت مرسوله شماره <?php echo htmlspecialchars($parcel['id']); ?></h2>
        <nav>
            <a href="index.php">مرسولات در انتظار</a>
            <a href="parcels.php">مرسولات من</a>
            <a href="wallet.php">کیف پول</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <h3>جزئیات مرسوله</h3>
        <p><strong>فرستنده:</strong> <?php echo htmlspecialchars($parcel['sender_name']); ?> (<?php echo htmlspecialchars($parcel['sender_mobile']); ?>)</p>
        <p><strong>آدرس فرستنده:</strong> <?php echo htmlspecialchars($parcel['sender_address']); ?></p>
        <p><strong>گیرنده:</strong> <?php echo htmlspecialchars($parcel['receiver_name']); ?> (<?php echo htmlspecialchars($parcel['receiver_mobile']); ?>)</p>
        <p><strong>آدرس گیرنده:</strong> <?php echo htmlspecialchars($parcel['receiver_address']); ?></p>
        <p><strong>محصول:</strong> <?php echo htmlspecialchars($parcel['product']); ?></p>
        <p><strong>وزن:</strong> <?php echo $parcel['weight'] ? htmlspecialchars($parcel['weight']) . ' کیلوگرم' : 'مشخص نشده'; ?></p>
        <p><strong>توضیحات:</strong> <?php echo $parcel['description'] ? htmlspecialchars($parcel['description']) : 'ندارد'; ?></p>
        <p><strong>دستمزد:</strong> <?php echo number_format($parcel['courier_fee']); ?> تومان</p>
        <p><strong>وضعیت:</strong> <?php echo ['pending' => 'در انتظار', 'assigned' => 'اختصاص داده شده', 'shipping' => 'در حال ارسال', 'delivered' => 'تحویل شده'][$parcel['status']]; ?></p>
        <p><strong>تاریخ ثبت:</strong> <?php echo toShamsi($parcel['created_at']); ?></p>

        <?php if ($parcel['status'] !== 'delivered'): ?>
            <h3>آپدیت وضعیت</h3>
            <form method="POST" action="" id="status-form">
                <div class="form-group">
                    <label for="status">وضعیت جدید</label>
                    <select name="status" id="status" required>
                        <option value="assigned" <?php echo $parcel['status'] === 'assigned' ? 'selected' : ''; ?>>اختصاص داده شده</option>
                        <option value="shipping" <?php echo $parcel['status'] === 'shipping' ? 'selected' : ''; ?>>در حال ارسال</option>
                        <option value="delivered">تحویل شده</option>
                    </select>
                </div>
                <div class="form-group" id="delivery-code-group" style="display: none;">
                    <label for="delivery_code">کد تحویل (۵ رقمی)</label>
                    <input type="text" name="delivery_code" id="delivery_code" maxlength="5">
                </div>
                <button type="submit" name="update_status">بروزرسانی</button>
            </form>
            <form method="POST" action="">
                <button type="submit" name="cancel_parcel" onclick="return confirm('آیا مطمئن هستید که می‌خواهید مرسوله را لغو کنید؟');">لغو مرسوله</button>
            </form>
        <?php endif; ?>
    </div>
    <script>
        document.getElementById('status').addEventListener('change', function() {
            document.getElementById('delivery-code-group').style.display = this.value === 'delivered' ? 'block' : 'none';
        });
    </script>
</body>
</html>