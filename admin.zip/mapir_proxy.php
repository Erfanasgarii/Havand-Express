<?php
require_once 'includes/mapir_api.php';
require_once 'includes/functions.php';

header('Content-Type: application/json');

$lat = isset($_GET['lat']) ? (float)$_GET['lat'] : 0;
$lng = isset($_GET['lng']) ? (float)$_GET['lng'] : 0;

if ($lat && $lng) {
    $mapir = new MapIRAPI();
    $address = $mapir->reverseGeocode($lat, $lng);
    if ($address) {
        echo json_encode(['formatted_address' => $address]);
    } else {
        echo json_encode(['error' => $_SESSION['error']]);
    }
} else {
    echo json_encode(['error' => 'مختصات نامعتبر']);
}