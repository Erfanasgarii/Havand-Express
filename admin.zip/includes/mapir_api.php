<?php
require_once __DIR__ . '/../config.php';

class MapIRAPI {
    private $apiKey;
    private $baseUrl = 'https://map.ir';

    public function __construct() {
        $this->apiKey = MAPIR_API_KEY;
    }

    // تبدیل آدرس به مختصات (Geocoding)
    public function geocode($address) {
        $url = $this->baseUrl . '/v1/geocode/search?text=' . urlencode($address);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'x-api-key: ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode === 200) {
            $data = json_decode($response, true);
            if (isset($data['value'][0]['location'])) {
                return [
                    'lat' => $data['value'][0]['location']['y'],
                    'lng' => $data['value'][0]['location']['x']
                ];
            }
            setError('خطا در Geocoding: پاسخ نامعتبر از API - ' . $response);
            return false;
        }
        setError('خطا در Geocoding: کد ' . $httpCode . ($error ? ' - ' . $error : '') . ' - پاسخ: ' . $response);
        return false;
    }

    // تبدیل مختصات به آدرس (Reverse Geocoding)
    public function reverseGeocode($lat, $lng) {
        $url = $this->baseUrl . '/v1/geocode/reverse?lat=' . $lat . '&lon=' . $lng;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'x-api-key: ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode === 200) {
            $data = json_decode($response, true);
            if (isset($data['value']['address'])) {
                return $data['value']['address'];
            }
            setError('خطا در Reverse Geocoding: پاسخ نامعتبر از API - ' . $response);
            return false;
        }
        setError('خطا در Reverse Geocoding: کد ' . $httpCode . ($error ? ' - ' . $error : '') . ' - پاسخ: ' . $response);
        return false;
    }
}