<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isCourier()) {
    redirect('../login.php', 'لطفاً به عنوان سفیر وارد شوید', 'error');
}

// Pagination
$perPage = 20;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

// دریافت مرسولات در انتظار
$stmt = $conn->prepare("SELECT id, sender_name, receiver_name, product, created_at 
                        FROM parcels 
                        WHERE status = 'pending' AND assigned_courier_id IS NULL 
                        LIMIT ? OFFSET ?");
$stmt->bindValue(1, $perPage, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$parcels = $stmt->fetchAll();

// شمارش کل مرسولات برای pagination
$stmt = $conn->prepare("SELECT COUNT(*) FROM parcels WHERE status = 'pending' AND assigned_courier_id IS NULL");
$stmt->execute();
$totalParcels = $stmt->fetchColumn();
$totalPages = ceil($totalParcels / $perPage);

// اختصاص مرسوله
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_parcel'])) {
    $parcelId = (int)$_POST['parcel_id'];
    $courierId = $_SESSION['user_id'];

    // چک کردن اینکه مرسوله هنوز در انتظاره
    $stmt = $conn->prepare("SELECT status, assigned_courier_id FROM parcels WHERE id = ?");
    $stmt->execute([$parcelId]);
    $parcel = $stmt->fetch();

    if ($parcel && $parcel['status'] === 'pending' && !$parcel['assigned_courier_id']) {
        $conn->beginTransaction();
        try {
            // تخصیص مرسوله
            $stmt = $conn->prepare("UPDATE parcels SET status = 'assigned', assigned_courier_id = ? WHERE id = ?");
            $stmt->execute([$courierId, $parcelId]);

            // ثبت تخصیص
            $stmt = $conn->prepare("INSERT INTO assignments (parcel_id, courier_id, assigned_at) VALUES (?, ?, NOW())");
            $stmt->execute([$parcelId, $courierId]);

            // ثبت تاریخچه
            $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, 'assigned', ?, NOW())");
            $stmt->execute([$parcelId, $courierId]);

            $conn->commit();
            redirect('parcels.php', 'مرسوله با موفقیت اختصاص یافت', 'success');
        } catch (Exception $e) {
            $conn->rollBack();
            setError('خطا در اختصاص مرسوله: ' . $e->getMessage());
        }
    } else {
        setError('مرسوله در دسترس نیست');
    }
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد سفیر - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>داشبورد سفیر</h2>
        <nav>
            <a href="index.php">مرسولات در انتظار</a>
            <a href="parcels.php">مرسولات من</a>
            <a href="wallet.php">کیف پول</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <h3>مرسولات در انتظار</h3>
        <table>
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>فرستنده</th>
                    <th>گیرنده</th>
                    <th>محصول</th>
                    <th>تاریخ ثبت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($parcels as $parcel): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($parcel['id']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['sender_name']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['receiver_name']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['product']); ?></td>
                        <td><?php echo toShamsi($parcel['created_at']); ?></td>
                        <td>
                            <form method="POST" action="">
                                <input type="hidden" name="parcel_id" value="<?php echo $parcel['id']; ?>">
                                <button type="submit" name="assign_parcel">انتخاب</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <!-- Pagination -->
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>" <?php echo $page === $i ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>
    </div>
</body>
</html>