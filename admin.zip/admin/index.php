<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php', 'لطفاً به عنوان ادمین وارد شوید', 'error');
}

// آمار مرسولات
$stmt = $conn->prepare("SELECT status, COUNT(*) as count FROM parcels GROUP BY status");
$stmt->execute();
$statusCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// آمار عملکرد سفیرها
$stmt = $conn->prepare("SELECT u.name, COUNT(p.id) as parcel_count, SUM(p.courier_fee) as total_fee 
                        FROM users u 
                        LEFT JOIN parcels p ON u.id = p.assigned_courier_id 
                        WHERE u.role = 'courier' 
                        GROUP BY u.id");
$stmt->execute();
$courierStats = $stmt->fetchAll();

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد ادمین - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/chart.min.js" defer></script>
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>داشبورد ادمین</h2>
        <nav>
            <a href="index.php">داش