<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../login.php', 'لطفاً به عنوان ادمین وارد شوید', 'error');
}

// Pagination
$perPage = 20;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

// فیلترها
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';
$courierFilter = isset($_GET['courier_id']) ? (int)$_GET['courier_id'] : 0;
$dateFilter = isset($_GET['date']) ? $_GET['date'] : '';

$conditions = [];
$params = [];
if ($statusFilter) {
    $conditions[] = "status = ?";
    $params[] = $statusFilter;
}
if ($courierFilter) {
    $conditions[] = "assigned_courier_id = ?";
    $params[] = $courierFilter;
}
if ($dateFilter) {
    $conditions[] = "DATE(created_at) = ?";
    $params[] = $dateFilter;
}

$where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
$query = "SELECT p.id, p.sender_name, p.receiver_name, p.product, p.status, p.created_at, p.courier_fee, u.name as courier_name 
          FROM parcels p 
          LEFT JOIN users u ON p.assigned_courier_id = u.id 
          $where 
          LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;

$stmt = $conn->prepare($query);
$stmt->execute($params);
$parcels = $stmt->fetchAll();

// شمارش کل برای pagination
$countQuery = "SELECT COUNT(*) FROM parcels p $where";
$stmt = $conn->prepare($countQuery);
$stmt->execute(array_slice($params, 0, -2));
$totalParcels = $stmt->fetchColumn();
$totalPages = ceil($totalParcels / $perPage);

// دریافت سفیرها برای فیلتر
$stmt = $conn->prepare("SELECT id, name FROM users WHERE role = 'courier'");
$stmt->execute();
$couriers = $stmt->fetchAll();

// تخصیص دستی یا لغو
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_parcel'])) {
    $parcelId = (int)$_POST['parcel_id'];
    $courierId = (int)$_POST['courier_id'];

    $stmt = $conn->prepare("SELECT status, assigned_courier_id FROM parcels WHERE id = ?");
    $stmt->execute([$parcelId]);
    $parcel = $stmt->fetch();

    if ($parcel) {
        $conn->beginTransaction();
        try {
            $stmt = $conn->prepare("UPDATE parcels SET status = 'assigned', assigned_courier_id = ? WHERE id = ?");
            $stmt->execute([$courierId, $parcelId]);

            $stmt = $conn->prepare("INSERT INTO assignments (parcel_id, courier_id, assigned_at) VALUES (?, ?, NOW())");
            $stmt->execute([$parcelId, $courierId]);

            $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, 'assigned', ?, NOW())");
            $stmt->execute([$parcelId, $_SESSION['user_id']]);

            $conn->commit();
            redirect('parcels.php', 'مرسوله با موفقیت اختصاص یافت', 'success');
        } catch (Exception $e) {
            $conn->rollBack();
            setError('خطا در اختصاص مرسوله: ' . $e->getMessage());
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_assignment'])) {
    $parcelId = (int)$_POST['parcel_id'];

    $conn->beginTransaction();
    try {
        $stmt = $conn->prepare("UPDATE parcels SET status = 'pending', assigned_courier_id = NULL, attempts = 0 WHERE id = ?");
        $stmt->execute([$parcelId]);

        $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, 'pending', ?, NOW())");
        $stmt->execute([$parcelId, $_SESSION['user_id']]);

        $conn->commit();
        redirect('parcels.php', 'اختصاص مرسوله لغو شد', 'success');
    } catch (Exception $e) {
        $conn->rollBack();
        setError('خطا در لغو اختصاص: ' . $e->getMessage());
    }
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت مرسولات - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>مدیریت مرسولات</h2>
        <nav>
            <a href="index.php">داشبورد</a>
            <a href="parcels.php">مدیریت مرسولات</a>
            <a href="couriers.php">مدیریت سفیرها</a>
            <a href="withdrawals.php">درخواست‌های برداشت</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <h3>فیلترها</h3>
        <form method="GET" action="">
            <div class="form-group">
                <label for="status">وضعیت</label>
                <select name="status" id="status">
                    <option value="">همه</option>
                    <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>در انتظار</option>
                    <option value="assigned" <?php echo $statusFilter === 'assigned' ? 'selected' : ''; ?>>اختصاص داده شده</option>
                    <option value="shipping" <?php echo $statusFilter === 'shipping' ? 'selected' : ''; ?>>در حال ارسال</option>
                    <option value="delivered" <?php echo $statusFilter === 'delivered' ? 'selected' : ''; ?>>تحویل شده</option>
                </select>
            </div>
            <div class="form-group">
                <label for="courier_id">سفیر</label>
                <select name="courier_id" id="courier_id">
                    <option value="0">همه</option>
                    <?php foreach ($couriers as $courier): ?>
                        <option value="<?php echo $courier['id']; ?>" <?php echo $courierFilter === $courier['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($courier['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="date">تاریخ</label>
                <input type="date" name="date" id="date" value="<?php echo htmlspecialchars($dateFilter); ?>">
            </div>
            <button type="submit">فیلتر</button>
        </form>
        <h3>لیست مرسولات</h3>
        <table>
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>فرستنده</th>
                    <th>گیرنده</th>
                    <th>محصول</th>
                    <th>وضعیت</th>
                    <th>دستمزد (تومان)</th>
                    <th>سفیر</th>
                    <th>تاریخ ثبت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($parcels as $parcel): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($parcel['id']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['sender_name']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['receiver_name']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['product']); ?></td>
                        <td><?php echo ['pending' => 'در انتظار', 'assigned' => 'اختصاص داده شده', 'shipping' => 'در حال ارسال', 'delivered' => 'تحویل شده'][$parcel['status']]; ?></td>
                        <td><?php echo number_format($parcel['courier_fee']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['courier_name'] ?: '-'); ?></td>
                        <td><?php echo toShamsi($parcel['created_at']); ?></td>
                        <td>
                            <?php if ($parcel['status'] !== 'delivered'): ?>
                                <form method="POST" action="">
                                    <input type="hidden" name="parcel_id" value="<?php echo $parcel['id']; ?>">
                                    <select name="courier_id">
                                        <option value="0">بدون سفیر</option>
                                        <?php foreach ($couriers as $courier): ?>
                                            <option value="<?php echo $courier['id']; ?>" <?php echo $parcel['assigned_courier_id'] === $courier['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($courier['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="assign_parcel">تخصیص</button>
                                    <?php if ($parcel['assigned_courier_id']): ?>
                                        <button type="submit" name="cancel_assignment">لغو تخصیص</button>
                                    <?php endif; ?>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($statusFilter); ?>&courier_id=<?php echo $courierFilter; ?>&date=<?php echo urlencode($dateFilter); ?>" 
                   <?php echo $page === $i ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>
        <a href="parcel_add.php">ثبت مرسوله جدید</a>
    </div>
</body>
</html>