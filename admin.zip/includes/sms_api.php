<?php
require_once __DIR__ . '/../config.php';

class SMSIR {
    private $apiKey;
    private $patternId;
    private $apiUrl = 'https://api.sms.ir/v1/send/verify';

    public function __construct() {
        $this->apiKey = SMS_API_KEY; // از config.php
        $this->patternId = SMS_PATTERN_ID; // 358841
    }

    public function sendOTP($mobile, $otp) {
        $data = [
            'mobile' => $mobile,
            'templateId' => $this->patternId,
            'parameters' => [
                ['name' => 'CODE', 'value' => $otp]
            ]
        ];

        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'x-api-key: ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            $result = json_decode($response, true);
            if (isset($result['status']) && $result['status'] === 1) {
                return true;
            }
            setError('خطا در ارسال پیامک: ' . ($result['message'] ?? 'نامشخص'));
            return false;
        }

        setError('خطا در اتصال به SMS.ir: کد ' . $httpCode);
        return false;
    }
}