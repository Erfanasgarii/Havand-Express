<?php
require_once __DIR__ . '/../assets/lib/jdf.php'; // مسیر اصلاح‌شده
require_once __DIR__ . '/../config.php'; // تنظیمات

// تبدیل تاریخ میلادی به شمسی
function toShamsi($datetime) {
    $timestamp = strtotime($datetime);
    $shamsi = jdate('Y/m/d H:i', $timestamp, '', 'Asia/Tehran', 'fa');
    return $shamsi;
}

// اعتبارسنجی شماره موبایل (09xxxxxxxxx)
function validateMobile($mobile) {
    return preg_match('/^09[0-9]{9}$/', $mobile);
}

// اعتبارسنجی کد تحویل (۵ رقمی)
function validateDeliveryCode($code) {
    return preg_match('/^[0-9]{5}$/', $code);
}

// هش کردن کد تحویل یا OTP
function hashCode($code) {
    return password_hash($code, PASSWORD_BCRYPT);
}

// تأیید کد تحویل یا OTP
function verifyCode($inputCode, $hashedCode) {
    return password_verify($inputCode, $hashedCode);
}

// تولید پیام خطا
function setError($message) {
    $_SESSION['error'] = $message;
}

// تولید پیام موفقیت
function setSuccess($message) {
    $_SESSION['success'] = $message;
}

// بررسی لاگین بودن کاربر
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
}

// بررسی نقش کاربر
function isAdmin() {
    return isLoggedIn() && $_SESSION['user_role'] === 'admin';
}

function isCourier() {
    return isLoggedIn() && $_SESSION['user_role'] === 'courier';
}

// ریدایرکت با پیام
function redirect($url, $message = null, $type = 'error') {
    if ($message) {
        if ($type === 'error') {
            setError($message);
        } else {
            setSuccess($message);
        }
    }
    header("Location: $url");
    exit;
}