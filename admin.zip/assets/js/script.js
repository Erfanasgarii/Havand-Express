// اعتبارسنجی فرم موبایل
document.addEventListener('DOMContentLoaded', () => {
    // تأخیر برای اطمینان از لود کامل DOM و SDK
    setTimeout(() => {
        const mobileForm = document.getElementById('mobile-form');
        if (mobileForm) {
            mobileForm.addEventListener('submit', (e) => {
                const mobile = document.getElementById('mobile').value;
                if (!/^09[0-9]{9}$/.test(mobile)) {
                    e.preventDefault();
                    alert('شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود');
                }
            });
        }

        // مدیریت دکمه ارسال مجدد OTP
        const resendButton = document.getElementById('resend-otp');
        if (resendButton) {
            let countdown = 120;
            resendButton.textContent = `ارسال مجدد (${countdown} ثانیه)`;
            const timer = setInterval(() => {
                countdown--;
                resendButton.textContent = `ارسال مجدد (${countdown} ثانیه)`;
                if (countdown <= 0) {
                    resendButton.disabled = false;
                    resendButton.textContent = 'ارسال مجدد';
                    clearInterval(timer);
                }
            }, 1000);
        }

        // اعتبارسنجی فرم OTP
        const otpForm = document.getElementById('otp-form');
        if (otpForm) {
            otpForm.addEventListener('submit', (e) => {
                const otp = document.getElementById('otp').value;
                if (!/^[0-9]{4}$/.test(otp)) {
                    e.preventDefault();
                    alert('کد تأیید باید ۴ رقم عددی باشد');
                }
            });
        }

        // اعتبارسنجی فرم کد تحویل
        const statusForm = document.getElementById('status-form');
        if (statusForm) {
            statusForm.addEventListener('submit', (e) => {
                const status = document.getElementById('status').value;
                if (status === 'delivered') {
                    const deliveryCode = document.getElementById('delivery_code').value;
                    if (!/^[0-9]{5}$/.test(deliveryCode)) {
                        e.preventDefault();
                        alert('کد تحویل باید ۵ رقم عددی باشد');
                    }
                }
            });
        }

        // اعتبارسنجی فرم برداشت
        const withdrawalForm = document.getElementById('withdrawal-form');
        if (withdrawalForm) {
            withdrawalForm.addEventListener('submit', (e) => {
                const amount = parseInt(document.getElementById('amount').value);
                const sheba = document.getElementById('sheba').value;
                const cardNumber = document.getElementById('card_number').value;
                if (amount < 500000) {
                    e.preventDefault();
                    alert('حداقل مبلغ برداشت ۵۰۰,۰۰۰ تومان است');
                }
                if (!/^IR[0-9]{24}$/.test(sheba) && !/^[0-9]{16}$/.test(cardNumber)) {
                    e.preventDefault();
                    alert('شماره شبا یا کارت نامعتبر است');
                }
            });
        }

        // نقشه Map.ir برای فرم فرستنده
        const senderMapDiv = document.querySelector('#sender_map');
        if (senderMapDiv && typeof Mapp !== 'undefined') {
            const map = new Mapp({
                element: '#sender_map',
                presets: {
                    lat: 35.6892,
                    lng: 51.3890,
                    zoom: 13
                },
                apiKey: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjlkNTc1YWFkY2ViZDcyYWY1MWUxNzJlYzU0MjFmODBmMTMxZDcxN2JkOTI4MGY2NGYwMDExMjk4OTQzNTNlMWE5MzY4Y2M3Mzc4NDE2ODI0In0.eyJhdWQiOiIzNDExMCIsImp0aSI6IjlkNTc1YWFkY2ViZDcyYWY1MWUxNzJlYzU0MjFmODBmMTMxZDcxN2JkOTI4MGY2NGYwMDExMjk4OTQzNTNlMWE5MzY4Y2M3Mzc4NDE2ODI0IiwiaWF0IjoxNzU2NDk2NzAzLCJuYmYiOjE3NTY0OTY3MDMsImV4cCI6MTc1OTA4ODcwMywic3ViIjoiIiwic2NvcGVzIjpbImJhc2ljIl19.Kqy7D9cJQb0W482OMca7D1VED5m_-KdCseAnTkWRDRHy1Y2DkU0k93jImkSltqG4Q7FB2hsOQ6VRfHi6XwVBBBys8HYhRpjS_NVwLtFWK8YtsQdzdRKDquZ1EDjAACtih5OGlRw71MyDg4jx0JoKAibowDO8YVHJgK59YNHpZuDv_bt9dqDmwxdAZ-ti9gXKAprUv3hr487o5eTWWRQpi6mXAmJR7M1Amn2MpCsCOQ3aABjg0CG8oLpM7jV3ThIQBrEVRX8SjlKnv_GmRZiSWOjwBXvfVb4TJjNPUSZM3lCbAYJWy3aVeBu0vcJ74SjVrZZpipA2tiTYJxciIpl8Ow'
            });
            map.addLayers();

            let marker;
            map.map.on('click', (e) => {
                console.log('رویداد کلیک:', e); // دیباگ کامل رویداد
                if (!e.latLng || typeof e.latLng.lat === 'undefined' || typeof e.latLng.lng === 'undefined' || 
                    e.latLng.lat < 25 || e.latLng.lat > 40 || e.latLng.lng < 44 || e.latLng.lng > 63) {
                    console.error('مختصات نامعتبر در رویداد کلیک:', e);
                    return;
                }
                if (marker) {
                    marker.setLatLng(e.latLng);
                } else {
                    marker = map.addMarker({
                        lat: e.latLng.lat,
                        lng: e.latLng.lng
                    });
                }
                document.getElementById('sender_lat').value = e.latLng.lat;
                document.getElementById('sender_lng').value = e.latLng.lng;

                fetch('/auth/mapir_proxy.php?lat=' + e.latLng.lat + '&lng=' + e.latLng.lng)
                    .then(response => response.json())
                    .then(data => {
                        if (data.formatted_address) {
                            document.getElementById('sender_address').value = data.formatted_address;
                        } else {
                            console.error('خطا در دریافت آدرس:', data.error || 'نامشخص');
                            alert('خطا در دریافت آدرس: ' + (data.error || 'نامشخص'));
                        }
                    })
                    .catch(error => {
                        console.error('خطا در ارتباط با سرور:', error.message);
                        alert('خطا در ارتباط با سرور: ' + error.message);
                    });
            });
        } else {
            console.error('کتابخانه Map.ir SDK یا #sender_map لود نشد.');
            alert('نقشه فرستنده لود نشد. لطفاً صفحه را رفرش کنید.');
        }

        // نقشه Map.ir برای فرم گیرنده
        const receiverMapDiv = document.querySelector('#receiver_map');
        if (receiverMapDiv && typeof Mapp !== 'undefined') {
            const map = new Mapp({
                element: '#receiver_map',
                presets: {
                    lat: 35.6892,
                    lng: 51.3890,
                    zoom: 13
                },
                apiKey: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjlkNTc1YWFkY2ViZDcyYWY1MWUxNzJlYzU0MjFmODBmMTMxZDcxN2JkOTI4MGY2NGYwMDExMjk4OTQzNTNlMWE5MzY4Y2M3Mzc4NDE2ODI0In0.eyJhdWQiOiIzNDExMCIsImp0aSI6IjlkNTc1YWFkY2ViZDcyYWY1MWUxNzJlYzU0MjFmODBmMTMxZDcxN2JkOTI4MGY2NGYwMDExMjk4OTQzNTNlMWE5MzY4Y2M3Mzc4NDE2ODI0IiwiaWF0IjoxNzU2NDk2NzAzLCJuYmYiOjE3NTY0OTY3MDMsImV4cCI6MTc1OTA4ODcwMywic3ViIjoiIiwic2NvcGVzIjpbImJhc2ljIl19.Kqy7D9cJQb0W482OMca7D1VED5m_-KdCseAnTkWRDRHy1Y2DkU0k93jImkSltqG4Q7FB2hsOQ6VRfHi6XwVBBBys8HYhRpjS_NVwLtFWK8YtsQdzdRKDquZ1EDjAACtih5OGlRw71MyDg4jx0JoKAibowDO8YVHJgK59YNHpZuDv_bt9dqDmwxdAZ-ti9gXKAprUv3hr487o5eTWWRQpi6mXAmJR7M1Amn2MpCsCOQ3aABjg0CG8oLpM7jV3ThIQBrEVRX8SjlKnv_GmRZiSWOjwBXvfVb4TJjNPUSZM3lCbAYJWy3aVeBu0vcJ74SjVrZZpipA2tiTYJxciIpl8Ow'
            });
            map.addLayers();

            let marker;
            map.map.on('click', (e) => {
                console.log('رویداد کلیک:', e); // دیباگ کامل رویداد
                if (!e.latLng || typeof e.latLng.lat === 'undefined' || typeof e.latLng.lng === 'undefined' || 
                    e.latLng.lat < 25 || e.latLng.lat > 40 || e.latLng.lng < 44 || e.latLng.lng > 63) {
                    console.error('مختصات نامعتبر در رویداد کلیک:', e);
                    return;
                }
                if (marker) {
                    marker.setLatLng(e.latLng);
                } else {
                    marker = map.addMarker({
                        lat: e.latLng.lat,
                        lng: e.latLng.lng
                    });
                }
                document.getElementById('receiver_lat').value = e.latLng.lat;
                document.getElementById('receiver_lng').value = e.latLng.lng;

                fetch('/auth/mapir_proxy.php?lat=' + e.latLng.lat + '&lng=' + e.latLng.lng)
                    .then(response => response.json())
                    .then(data => {
                        if (data.formatted_address) {
                            document.getElementById('receiver_address').value = data.formatted_address;
                        } else {
                            console.error('خطا در دریافت آدرس:', data.error || 'نامشخص');
                            alert('خطا در دریافت آدرس: ' + (data.error || 'نامشخص'));
                        }
                    })
                    .catch(error => {
                        console.error('خطا در ارتباط با سرور:', error.message);
                        alert('خطا در ارتباط با سرور: ' + error.message);
                    });
            });
        } else if (document.getElementById('receiver-form')) {
            console.warn('نقشه گیرنده لود نشد، چون در این مرحله نمایش داده نمی‌شود.');
        }

        // اعتبارسنجی فرم فرستنده
        const senderForm = document.getElementById('sender-form');
        if (senderForm) {
            senderForm.addEventListener('submit', (e) => {
                const mobile = document.getElementById('sender_mobile').value;
                const lat = document.getElementById('sender_lat').value;
                const lng = document.getElementById('sender_lng').value;
                if (!/^09[0-9]{9}$/.test(mobile)) {
                    e.preventDefault();
                    alert('شماره موبایل فرستنده باید ۱۱ رقم و با ۰۹ شروع شود');
                }
                if (!lat || !lng) {
                    e.preventDefault();
                    alert('لطفاً موقعیت فرستنده را روی نقشه انتخاب کنید');
                }
            });
        }

        // اعتبارسنجی فرم گیرنده
        const receiverForm = document.getElementById('receiver-form');
        if (receiverForm) {
            receiverForm.addEventListener('submit', (e) => {
                const mobile = document.getElementById('receiver_mobile').value;
                const lat = document.getElementById('receiver_lat').value;
                const lng = document.getElementById('receiver_lng').value;
                const deliveryCode = document.getElementById('delivery_code').value;
                const courierFee = parseInt(document.getElementById('courier_fee').value);
                if (!/^09[0-9]{9}$/.test(mobile)) {
                    e.preventDefault();
                    alert('شماره موبایل گیرنده باید ۱۱ رقم و با ۰۹ شروع شود');
                }
                if (!lat || !lng) {
                    e.preventDefault();
                    alert('لطفاً موقعیت گیرنده را روی نقشه انتخاب کنید');
                }
                if (!/^[0-9]{5}$/.test(deliveryCode)) {
                    e.preventDefault();
                    alert('کد تحویل باید ۵ رقم عددی باشد');
                }
                if (courierFee <= 0) {
                    e.preventDefault();
                    alert('دستمزد سفیر باید بیشتر از صفر باشد');
                }
            });
        }
    }, 1000); // تأخیر 1000ms برای اطمینان از لود کامل SDK و لایه‌ها
});