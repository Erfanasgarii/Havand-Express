<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

if (!isCourier()) {
    redirect('../login.php', 'لطفاً به عنوان سفیر وارد شوید', 'error');
}

$courierId = $_SESSION['user_id'];

// دریافت مرسولات اختصاص‌یافته
$stmt = $conn->prepare("SELECT id, sender_name, receiver_name, product, status, created_at, courier_fee 
                        FROM parcels 
                        WHERE assigned_courier_id = ?");
$stmt->execute([$courierId]);
$parcels = $stmt->fetchAll();

// دریافت تاریخچه
$stmt = $conn->prepare("SELECT p.id, p.sender_name, p.receiver_name, p.product, s.status, s.updated_at 
                        FROM parcels p 
                        JOIN status_updates s ON p.id = s.parcel_id 
                        WHERE p.assigned_courier_id = ? 
                        ORDER BY s.updated_at DESC");
$stmt->execute([$courierId]);
$history = $stmt->fetchAll();

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مرسولات من - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>مرسولات من</h2>
        <nav>
            <a href="index.php">مرسولات در انتظار</a>
            <a href="parcels.php">مرسولات من</a>
            <a href="wallet.php">کیف پول</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <h3>مرسولات اختصاص‌یافته</h3>
        <table>
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>فرستنده</th>
                    <th>گیرنده</th>
                    <th>محصول</th>
                    <th>وضعیت</th>
                    <th>دستمزد (تومان)</th>
                    <th>تاریخ ثبت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($parcels as $parcel): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($parcel['id']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['sender_name']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['receiver_name']); ?></td>
                        <td><?php echo htmlspecialchars($parcel['product']); ?></td>
                        <td><?php echo ['pending' => 'در انتظار', 'assigned' => 'اختصاص داده شده', 'shipping' => 'در حال ارسال', 'delivered' => 'تحویل شده'][$parcel['status']]; ?></td>
                        <td><?php echo number_format($parcel['courier_fee']); ?></td>
                        <td><?php echo toShamsi($parcel['created_at']); ?></td>
                        <td>
                            <a href="parcel_status.php?id=<?php echo $parcel['id']; ?>">مدیریت</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <h3>تاریخچه مرسولات</h3>
        <table>
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>فرستنده</th>
                    <th>گیرنده</th>
                    <th>محصول</th>
                    <th>وضعیت</th>
                    <th>تاریخ آپدیت</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($history as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['id']); ?></td>
                        <td><?php echo htmlspecialchars($item['sender_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['receiver_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['product']); ?></td>
                        <td><?php echo ['pending' => 'در انتظار', 'assigned' => 'اختصاص داده شده', 'shipping' => 'در حال ارسال', 'delivered' => 'تحویل شده'][$item['status']]; ?></td>
                        <td><?php echo toShamsi($item['updated_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>