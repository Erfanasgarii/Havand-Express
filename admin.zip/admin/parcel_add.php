<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';
require_once '../includes/mapir_api.php';

if (!isAdmin()) {
    redirect('../login.php', 'لطفاً به عنوان ادمین وارد شوید', 'error');
}

$step = isset($_POST['step']) ? $_POST['step'] : 'sender';
$data = $_SESSION['parcel_data'] ?? [];
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 'sender') {
        $data['sender_name'] = trim($_POST['sender_name'] ?? '');
        $data['sender_mobile'] = trim($_POST['sender_mobile'] ?? '');
        $data['sender_address'] = trim($_POST['sender_address'] ?? '');
        $data['sender_lat'] = $_POST['sender_lat'] ?? '';
        $data['sender_lng'] = $_POST['sender_lng'] ?? '';

        if (!$data['sender_name'] || !validateMobile($data['sender_mobile']) || !$data['sender_address'] || !$data['sender_lat'] || !$data['sender_lng']) {
            setError('لطفاً تمام فیلدهای فرستنده را پر کنید');
        } else {
            $_SESSION['parcel_data'] = $data;
            $step = 'receiver';
        }
    } elseif ($step === 'receiver') {
        $data['receiver_name'] = trim($_POST['receiver_name'] ?? '');
        $data['receiver_mobile'] = trim($_POST['receiver_mobile'] ?? '');
        $data['receiver_address'] = trim($_POST['receiver_address'] ?? '');
        $data['receiver_lat'] = $_POST['receiver_lat'] ?? '';
        $data['receiver_lng'] = $_POST['receiver_lng'] ?? '';
        $data['product'] = trim($_POST['product'] ?? '');
        $data['weight'] = $_POST['weight'] ? (float)$_POST['weight'] : null;
        $data['description'] = trim($_POST['description'] ?? '');
        $data['courier_fee'] = (int)$_POST['courier_fee'] ?? 0;
        $data['delivery_code'] = trim($_POST['delivery_code'] ?? '');

        if (!$data['receiver_name'] || !validateMobile($data['receiver_mobile']) || !$data['receiver_address'] || 
            !$data['receiver_lat'] || !$data['receiver_lng'] || !$data['product'] || !$data['courier_fee'] || 
            !validateDeliveryCode($data['delivery_code'])) {
            setError('لطفاً تمام فیلدهای گیرنده را پر کنید');
        } else {
            $conn->beginTransaction();
            try {
                $stmt = $conn->prepare("INSERT INTO parcels (sender_name, sender_mobile, sender_address, sender_lat, sender_lng, 
                                        receiver_name, receiver_mobile, receiver_address, receiver_lat, receiver_lng, 
                                        product, weight, description, courier_fee, delivery_code, status, created_at) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())");
                $stmt->execute([
                    $data['sender_name'], $data['sender_mobile'], $data['sender_address'], $data['sender_lat'], $data['sender_lng'],
                    $data['receiver_name'], $data['receiver_mobile'], $data['receiver_address'], $data['receiver_lat'], $data['receiver_lng'],
                    $data['product'], $data['weight'], $data['description'], $data['courier_fee'], hashCode($data['delivery_code'])
                ]);

                $parcelId = $conn->lastInsertId();
                $stmt = $conn->prepare("INSERT INTO status_updates (parcel_id, status, updated_by, updated_at) VALUES (?, 'pending', ?, NOW())");
                $stmt->execute([$parcelId, $_SESSION['user_id']]);

                $conn->commit();
                unset($_SESSION['parcel_data']);
                redirect('parcels.php', 'مرسوله با موفقیت ثبت شد', 'success');
            } catch (Exception $e) {
                $conn->rollBack();
                setError('خطا در ثبت مرسوله: ' . $e->getMessage());
            }
        }
    }
}

unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت مرسوله - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <link rel="stylesheet" href="https://cdn.map.ir/web-sdk/1.4.2/css/mapp.min.css">
    <link rel="stylesheet" href="https://cdn.map.ir/web-sdk/1.4.2/css/fa/style.css">
    <link rel="icon" href="data:image/x-icon;base64,AAABAAEAEBAQAAEABAAoAQAAFgAAACgAAAAQAAAAIAAAAAEABAAAAAAAgAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAKysrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAA==">
</head>
<body>
    <div class="container">
        <h2>ثبت مرسوله جدید</h2>
        <nav>
            <a href="index.php">داشبورد</a>
            <a href="parcels.php">مدیریت مرسولات</a>
            <a href="couriers.php">مدیریت سفیرها</a>
            <a href="withdrawals.php">درخواست‌های برداشت</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if ($step === 'sender'): ?>
            <h3>مرحله ۱: اطلاعات فرستنده</h3>
            <form method="POST" action="" id="sender-form">
                <input type="hidden" name="step" value="sender">
                <div class="form-group">
                    <label for="sender_name">نام فرستنده</label>
                    <input type="text" name="sender_name" id="sender_name" value="<?php echo htmlspecialchars($data['sender_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="sender_mobile">موبایل فرستنده</label>
                    <input type="text" name="sender_mobile" id="sender_mobile" value="<?php echo htmlspecialchars($data['sender_mobile'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="sender_address">آدرس فرستنده</label>
                    <input type="text" name="sender_address" id="sender_address" value="<?php echo htmlspecialchars($data['sender_address'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>موقعیت فرستنده</label>
                    <div id="sender_map" style="width: 300px; height: 200px;"></div>
                    <input type="hidden" name="sender_lat" id="sender_lat" value="<?php echo htmlspecialchars($data['sender_lat'] ?? ''); ?>">
                    <input type="hidden" name="sender_lng" id="sender_lng" value="<?php echo htmlspecialchars($data['sender_lng'] ?? ''); ?>">
                </div>
                <button type="submit">بعدی</button>
            </form>
        <?php elseif ($step === 'receiver'): ?>
            <h3>مرحله ۲: اطلاعات گیرنده</h3>
            <form method="POST" action="" id="receiver-form">
                <input type="hidden" name="step" value="receiver">
                <div class="form-group">
                    <label for="receiver_name">نام گیرنده</label>
                    <input type="text" name="receiver_name" id="receiver_name" value="<?php echo htmlspecialchars($data['receiver_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="receiver_mobile">موبایل گیرنده</label>
                    <input type="text" name="receiver_mobile" id="receiver_mobile" value="<?php echo htmlspecialchars($data['receiver_mobile'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="receiver_address">آدرس گیرنده</label>
                    <input type="text" name="receiver_address" id="receiver_address" value="<?php echo htmlspecialchars($data['receiver_address'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>موقعیت گیرنده</label>
                    <div id="receiver_map" style="width: 300px; height: 200px;"></div>
                    <input type="hidden" name="receiver_lat" id="receiver_lat" value="<?php echo htmlspecialchars($data['receiver_lat'] ?? ''); ?>">
                    <input type="hidden" name="receiver_lng" id="receiver_lng" value="<?php echo htmlspecialchars($data['receiver_lng'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="product">محصول</label>
                    <input type="text" name="product" id="product" value="<?php echo htmlspecialchars($data['product'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="weight">وزن (کیلوگرم، اختیاری)</label>
                    <input type="number" name="weight" id="weight" step="0.01" value="<?php echo htmlspecialchars($data['weight'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="description">توضیحات (اختیاری)</label>
                    <textarea name="description" id="description"><?php echo htmlspecialchars($data['description'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="courier_fee">دستمزد سفیر (تومان)</label>
                    <input type="number" name="courier_fee" id="courier_fee" value="<?php echo htmlspecialchars($data['courier_fee'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="delivery_code">کد تحویل (۵ رقمی)</label>
                    <input type="text" name="delivery_code" id="delivery_code" maxlength="5" value="<?php echo htmlspecialchars($data['delivery_code'] ?? ''); ?>" required>
                </div>
                <button type="submit">ثبت مرسوله</button>
                <button type="button" onclick="window.location.href='parcel_add.php?step=sender'">قبلی</button>
            </form>
        <?php endif; ?>
    </div>
    <script type="text/javascript" src="https://cdn.map.ir/web-sdk/1.4.2/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdn.map.ir/web-sdk/1.4.2/js/mapp.env.js"></script>
    <script type="text/javascript" src="https://cdn.map.ir/web-sdk/1.4.2/js/mapp.min.js"></script>
    <script src="../assets/js/script.js" defer></script>
</body>
</html>