<?php
require_once '../includes/auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';
require_once '../includes/wallet.php';

if (!isAdmin()) {
    redirect('../login.php', 'لطفاً به عنوان ادمین وارد شوید', 'error');
}

$stmt = $conn->prepare("SELECT w.id, w.courier_id, w.amount, w.sheba, w.card_number, w.status, w.rejection_reason, w.created_at, u.name 
                        FROM withdrawal_requests w 
                        JOIN users u ON w.courier_id = u.id 
                        ORDER BY w.created_at DESC");
$stmt->execute();
$requests = $stmt->fetchAll();

// تأیید یا رد درخواست
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_withdrawal'])) {
    $requestId = (int)$_POST['request_id'];
    $courierId = (int)$_POST['courier_id'];
    $amount = (int)$_POST['amount'];

    $stmt = $conn->prepare("SELECT balance FROM wallet WHERE courier_id = ?");
    $stmt->execute([$courierId]);
    $balance = $stmt->fetchColumn();

    if ($balance < $amount) {
        setError('موجودی کافی نیست');
    } else {
        $conn->beginTransaction();
        try {
            $stmt = $conn->prepare("UPDATE withdrawal_requests SET status = 'approved', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$requestId]);

            $stmt = $conn->prepare("UPDATE wallet SET balance = balance - ?, updated_at = NOW() WHERE courier_id = ?");
            $stmt->execute([$amount, $courierId]);

            $stmt = $conn->prepare("INSERT INTO wallet_transactions (courier_id, amount, type, description, created_at) 
                                    VALUES (?, ?, 'withdrawal', ?, NOW())");
            $stmt->execute([$courierId, $amount, "برداشت تأییدشده (شناسه: $requestId)"]);

            $conn->commit();
            redirect('withdrawals.php', 'درخواست با موفقیت تأیید شد', 'success');
        } catch (Exception $e) {
            $conn->rollBack();
            setError('خطا در تأیید درخواست: ' . $e->getMessage());
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_withdrawal'])) {
    $requestId = (int)$_POST['request_id'];
    $rejectionReason = trim($_POST['rejection_reason'] ?? '');

    $stmt = $conn->prepare("UPDATE withdrawal_requests SET status = 'rejected', rejection_reason = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$rejectionReason ?: null, $requestId]);
    redirect('withdrawals.php', 'درخواست با موفقیت رد شد', 'success');
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>درخواست‌های برداشت - فروشگاه هاوند</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/vazir.css">
    <script src="../assets/js/script.js" defer></script>
</head>
<body>
    <div class="container">
        <h2>درخواست‌های برداشت</h2>
        <nav>
            <a href="index.php">داشبورد</a>
            <a href="parcels.php">مدیریت مرسولات</a>
            <a href="couriers.php">مدیریت سفیرها</a>
            <a href="withdrawals.php">درخواست‌های برداشت</a>
            <a href="../logout.php">خروج</a>
        </nav>
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <table>
            <thead>
                <tr>
                    <th>نام سفیر</th>
                    <th>مبلغ (تومان)</th>
                    <th>شبا</th>
                    <th>کارت</th>
                    <th>وضعیت</th>
                    <th>دلیل رد</th>
                    <th>تاریخ</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $req): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($req['name']); ?></td>
                        <td><?php echo number_format($req['amount']); ?></td>
                        <td><?php echo htmlspecialchars($req['sheba'] ?: '-'); ?></td>
                        <td><?php echo htmlspecialchars($req['card_number'] ?: '-'); ?></td>
                        <td class="<?php echo $req['status'] === 'pending' ? 'status-pending' : ($req['status'] === 'approved' ? 'status-approved' : 'status-rejected'); ?>">
                            <?php echo ['pending' => 'در انتظار تأیید', 'approved' => 'تأیید شده', 'rejected' => 'رد شده'][$req['status']]; ?>
                        </td>
                        <td><?php echo htmlspecialchars($req['rejection_reason'] ?: '-'); ?></td>
                        <td><?php echo toShamsi($req['created_at']); ?></td>
                        <td>
                            <?php if ($req['status'] === 'pending'): ?>
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                    <input type="hidden" name="courier_id" value="<?php echo $req['courier_id']; ?>">
                                    <input type="hidden" name="amount" value="<?php echo $req['amount']; ?>">
                                    <button type="submit" name="approve_withdrawal">تأیید</button>
                                </form>
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                    <input type="text" name="rejection_reason" placeholder="دلیل رد (اختیاری)">
                                    <button type="submit" name="reject_withdrawal">رد</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>