<?php
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

function addToWallet($courierId, $amount, $description) {
    global $conn;
    $conn->beginTransaction();
    try {
        $stmt = $conn->prepare("UPDATE wallet SET balance = balance + ?, updated_at = NOW() WHERE courier_id = ?");
        $stmt->execute([$amount, $courierId]);

        $stmt = $conn->prepare("INSERT INTO wallet_transactions (courier_id, amount, type, description, created_at) 
                                VALUES (?, ?, 'deposit', ?, NOW())");
        $stmt->execute([$courierId, $amount, $description]);

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollBack();
        setError('خطا در واریز به کیف پول: ' . $e->getMessage());
        return false;
    }
}

function withdrawFromWallet($courierId, $amount, $description) {
    global $conn;
    $stmt = $conn->prepare("SELECT balance FROM wallet WHERE courier_id = ?");
    $stmt->execute([$courierId]);
    $balance = $stmt->fetchColumn();

    if ($balance < $amount) {
        setError('موجودی کافی نیست');
        return false;
    }

    $conn->beginTransaction();
    try {
        $stmt = $conn->prepare("UPDATE wallet SET balance = balance - ?, updated_at = NOW() WHERE courier_id = ?");
        $stmt->execute([$amount, $courierId]);

        $stmt = $conn->prepare("INSERT INTO wallet_transactions (courier_id, amount, type, description, created_at) 
                                VALUES (?, ?, 'withdrawal', ?, NOW())");
        $stmt->execute([$courierId, $amount, $description]);

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollBack();
        setError('خطا در برداشت از کیف پول: ' . $e->getMessage());
        return false;
    }
}